<div class="col-lg-12 col-md-12">

    <div class="card">
        <div class="card-header">Students</div>
        <div class="card-body" >
            <div class="table-responsive">
                <div id="table"></div>
            </div>
        </div>
    </div>

</div>