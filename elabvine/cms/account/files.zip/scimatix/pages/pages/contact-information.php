<div class="alert alert-info alert-dismissible text-center">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>Alert!</strong> Edit your platform contact information.
</div>
<div style="height: 600px !important;overflow-y: auto;">

    <table class="table table-bordered table-dark">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Media</th>
                <th scope="col">Info</th>
                <th scope="col">Preview</th>
                <th scope="col">Edit</th>
            </tr>
        </thead>
        <tbody id="t-body">

        </tbody>
    </table>
</div>