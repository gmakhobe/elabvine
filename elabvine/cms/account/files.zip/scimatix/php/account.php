<?php
/*
if ($our_accountstatus == "not verified") {
    header("Location: verify-account.php");
} else {

    if ($our_status == "step 1") {
        header("Location: setup-config.php");
    } else {
        $status_firststep = "d-none";
        $status_secondstep = "";
    }
}
*/
?>